# Audit PDF bulk downloader

Downloads every attached PDF for a list of audit ids, reusing a logged-in Chrome
session — you authenticate once, not 400 times.

## Setup (once)

```powershell
pip install -r requirements.txt
python save_credentials.py     # optional, see "Credentials" below
```

## Normal run

```powershell
python chrome_session.py       # opens Chrome -> you log in -> exports the session
python extract_pdfs.py         # downloads everything
```

`chrome_session.py` opens Chrome using its **own profile folder** (`.chrome-profile/`).
That folder persists, so you log in **once** and later runs go straight through
without asking again. Your everyday Chrome is untouched and keeps working while
this runs.

> **Why a separate profile?** Chrome 136+ refuses `--remote-debugging-port` on your
> normal profile directory — a deliberate security fix that stopped local programs
> from reading your main browser session. A dedicated profile is the supported path.

Add `--autofill` to have it type your stored credentials into the login form, and
`--keep-open` to leave Chrome running during a long download (keeps the server
session warm).

## Credentials

**Recommended: Windows Credential Manager**, via `save_credentials.py`. The
password is typed at a hidden prompt and handed to Windows' encrypted credential
store — it never touches a file in this project, your shell history, or git.

```powershell
python save_credentials.py            # store
python save_credentials.py --show     # username only, never the password
python save_credentials.py --delete   # remove
```

View or delete them yourself any time: **Control Panel → Credential Manager → Windows Credentials**.

**Honestly, you may not need to store them at all.** The Chrome profile remembers
your login, so the normal flow is: log in by hand once, then never again. Stored
credentials only power the optional `--autofill`, and if your site uses MFA you'll
be finishing that by hand regardless.

**What not to do:** don't put the password in the `.py` files, and don't commit
`session.txt` — it holds live auth cookies, which are as good as the password
until they expire. Both are already in `.gitignore`, along with `downloads/` and
`.chrome-profile/`.

If you'd rather use a `.env` file than Credential Manager, it's a step down —
plaintext on disk — but `.env` is gitignored if you go that way.

## Skipping Chrome

`chrome_session.py` is just one way to fill `session.txt`. These also work:

- `python get_cookies.py` — reads cookies from your everyday browser without
  opening anything. Often fails on Chrome 127+ (encrypted cookie store).
- **Manual:** F12 → Network → open any grid URL → right-click the request →
  **Copy → Copy as cURL (bash)** → paste into `session.txt`. Always works, and it
  preserves every header the browser sent, so it's the fallback if the server
  rejects a bare cookie handoff.

## Input / output

`audit_ids.txt` — your ~400 ids, one per line (commas/spaces fine, `#` comments ignored).

```
downloads/
  audit_1119310/
    1008700000001119310_16477914.pdf
download_report.csv     # audit_id, filename, type, uploaded, status, bytes, path, url
```

## Options

| Command | Effect |
|---|---|
| `extract_pdfs.py --dry-run` | List targets, download nothing |
| `extract_pdfs.py --flat` | All PDFs in one folder instead of `audit_<id>/` |
| `extract_pdfs.py --workers 8` | More parallelism (default 4) |
| `extract_pdfs.py --out D:\pdfs` | Different output directory |
| `chrome_session.py --autofill` | Fill the login form from Credential Manager |
| `chrome_session.py --headless` | No window (only once the profile is logged in) |
| `chrome_session.py --download` | Let Chrome do the downloading (fallback, see below) |

## Notes

- **Resumable.** Completed files are skipped, so re-run after an interruption or
  to retry failures. Partial downloads sit in `.part` and are only renamed once
  complete — a killed run never leaves a truncated PDF.
- **Session expiry is caught** — the script stops with `AUTH FAILED` instead of
  silently saving 400 copies of the login page. Re-run `chrome_session.py`.
- **`--download` is a fallback, not the main path.** It navigates Chrome to each
  document URL and lets the browser save it: no retries, no per-file report, no
  parallelism, and files land wherever Chrome puts them. Use it only if the
  server rejects the cookie handoff.
- These are medical records — keep `downloads/` wherever your organisation's
  data-handling rules require.
