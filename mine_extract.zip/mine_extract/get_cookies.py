"""
Pull the exlservice.com session cookies straight out of your logged-in browser
and write them to session.txt for extract_pdfs.py.

    pip install browser-cookie3
    python get_cookies.py                # tries Chrome, Edge, Firefox
    python get_cookies.py --browser edge

If this fails (Chrome 127+ on Windows encrypts cookies with app-bound
encryption, which browser_cookie3 cannot always read), use the manual route --
it takes 15 seconds and always works:

    1. In your logged-in browser, press F12 -> Network tab.
    2. Open any audit grid URL, e.g.
       https://exlmine87.exlservice.com/Audit/AuditAttachedDocumentsGrid?auditIds=1119310&flowId=1
    3. Right-click the top request -> Copy -> Copy as cURL (bash).
    4. Paste the whole thing into session.txt and save.

extract_pdfs.py understands both formats.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

DOMAIN = "exlservice.com"
SESSION_FILE = Path(__file__).resolve().parent / "session.txt"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--browser", choices=["chrome", "edge", "firefox", "brave", "any"],
                        default="any")
    parser.add_argument("--domain", default=DOMAIN)
    args = parser.parse_args()

    try:
        import browser_cookie3
    except ImportError:
        sys.exit("browser-cookie3 not installed.  Run:  pip install browser-cookie3\n"
                 "(or use the manual 'Copy as cURL' route described at the top of this file)")

    loaders = {
        "chrome": browser_cookie3.chrome,
        "edge": browser_cookie3.edge,
        "firefox": browser_cookie3.firefox,
        "brave": browser_cookie3.brave,
    }
    order = [args.browser] if args.browser != "any" else ["chrome", "edge", "brave", "firefox"]

    for name in order:
        try:
            jar = loaders[name](domain_name=args.domain)
        except Exception as exc:  # noqa: BLE001 - browser locked, encrypted, not installed...
            print(f"  {name}: {exc}")
            continue

        pairs = [f"{c.name}={c.value}" for c in jar]
        if not pairs:
            print(f"  {name}: no cookies for {args.domain} (are you logged in there?)")
            continue

        SESSION_FILE.write_text("; ".join(pairs), encoding="utf-8")
        names = ", ".join(sorted({c.name for c in jar}))
        print(f"\nGrabbed {len(pairs)} cookie(s) from {name} -> {SESSION_FILE.name}")
        print(f"Cookies: {names}")
        if not any(n.lower() in {"asp.net_sessionid", ".aspxauth"} for n in {c.name.lower() for c in jar}):
            print("\nWARNING: no ASP.NET_SessionId / .ASPXAUTH cookie found. "
                  "If downloads fail, use the 'Copy as cURL' route instead.")
        print("\nNow run:  python extract_pdfs.py")
        return

    sys.exit("\nCould not read cookies from any browser.\n"
             "Use the manual 'Copy as cURL' route -- see the notes at the top of this file.")


if __name__ == "__main__":
    main()
