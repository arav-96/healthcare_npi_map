"""
Bulk-download audit PDFs from exlmine87.exlservice.com using your existing
browser login session.

HOW IT WORKS
------------
Each grid page (/Audit/AuditAttachedDocumentsGrid?auditIds=<id>&flowId=1) embeds
the document list inline as JavaScript:

    var myData = [{"ID":...,"AuditId":1119310,
                   "LinkToPDF":"<a href='/Audit/DisplayDocument?capId=11413&id=16477914&auditId=1119310'>...",
                   "DocumentName":"1008700000001119310_16477914.pdf", ...}];

So we:
  1. fetch the grid page for each audit id
  2. pull out the myData JSON
  3. hit /Audit/DisplayDocument?capId=..&id=..&auditId=.. for every row
  4. save the bytes as the row's DocumentName

USAGE
-----
  1. Log in to the site in your browser and leave the tab open.
  2. Put your session cookies in session.txt  (see get_cookies.py -- it can grab
     them automatically, or paste a "Copy as cURL" from DevTools).
  3. Put your audit ids in audit_ids.txt, one per line.
  4. python extract_pdfs.py

  python extract_pdfs.py --dry-run     # list what would be downloaded, download nothing
  python extract_pdfs.py --flat        # all PDFs in one folder instead of per-audit folders
  python extract_pdfs.py --workers 8   # more parallelism (default 4; be kind to the server)
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import shlex
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.parse import urljoin

import requests

# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #

BASE_URL = "https://exlmine87.exlservice.com"
GRID_PATH = "/Audit/AuditAttachedDocumentsGrid?auditIds={audit_id}&flowId={flow_id}"

HERE = Path(__file__).resolve().parent
SESSION_FILE = HERE / "session.txt"       # cookie header OR full "copy as cURL"
AUDIT_IDS_FILE = HERE / "audit_ids.txt"   # one audit id per line
OUTPUT_DIR = HERE / "downloads"
REPORT_FILE = HERE / "download_report.csv"

FLOW_ID = 1
TIMEOUT = 120          # seconds; big medical-record PDFs can be slow
RETRIES = 3
RETRY_BACKOFF = 3      # seconds, multiplied by attempt number
THROTTLE = 0.25        # polite pause between requests per worker

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)

# --------------------------------------------------------------------------- #
# Auth / session loading
# --------------------------------------------------------------------------- #


class AuthError(RuntimeError):
    """Raised when the server hands us a login page instead of real content."""


def load_session() -> requests.Session:
    """Build a requests.Session carrying your browser's cookies.

    session.txt may contain EITHER:
      * a raw Cookie header value:   ASP.NET_SessionId=abc; .ASPXAUTH=def; ...
      * a full DevTools "Copy as cURL (bash)" paste (we pull out every -H header)
    """
    if not SESSION_FILE.exists():
        sys.exit(
            f"Missing {SESSION_FILE.name}.\n"
            "Run:  python get_cookies.py       (auto-grab from your browser)\n"
            "or paste your cookies/cURL into session.txt -- see README_FIRST.md"
        )

    raw = SESSION_FILE.read_text(encoding="utf-8", errors="replace").strip()
    if not raw:
        sys.exit(f"{SESSION_FILE.name} is empty.")

    headers = {"User-Agent": USER_AGENT}

    if raw.lstrip().startswith("curl"):
        # DevTools "Copy as cURL" -- keep every header the browser sent.
        for token, value in _iter_curl_headers(raw):
            if token.lower() == "cookie" or not token.lower().startswith("sec-fetch"):
                headers[token] = value
        if "cookie" not in {k.lower() for k in headers}:
            sys.exit("That cURL paste has no Cookie header -- copy the request again while logged in.")
    else:
        # Raw cookie string. Tolerate a leading "Cookie:" and stray newlines.
        cookie = re.sub(r"^\s*cookie\s*:\s*", "", raw, flags=re.I)
        headers["Cookie"] = " ".join(cookie.split())

    session = requests.Session()
    session.headers.update(headers)
    return session


def _iter_curl_headers(curl_text: str):
    """Yield (name, value) for each -H/--header in a copied cURL command."""
    cleaned = curl_text.replace("\\\n", " ").replace("^\n", " ").replace("`\n", " ")
    try:
        parts = shlex.split(cleaned)
    except ValueError:
        parts = cleaned.split()
    for i, part in enumerate(parts):
        if part in ("-H", "--header") and i + 1 < len(parts):
            head = parts[i + 1]
            if ":" in head:
                name, _, value = head.partition(":")
                yield name.strip(), value.strip()
        elif part in ("-b", "--cookie") and i + 1 < len(parts):
            yield "Cookie", parts[i + 1].strip()


def looks_like_login(text: str) -> bool:
    """Detect the login/session-expired page the app serves when auth is stale."""
    probe = text[:4000].lower()
    signals = ("login.aspx", "id=\"txtusername\"", "sign in", "session has expired",
               "loginform", "/account/login", "password")
    return any(s in probe for s in signals) and "mydata" not in probe


# --------------------------------------------------------------------------- #
# Parsing the grid page
# --------------------------------------------------------------------------- #

MYDATA_RE = re.compile(r"var\s+myData\s*=\s*", re.I)
HREF_RE = re.compile(r"""href\s*=\s*['"]([^'"]+DisplayDocument[^'"]*)['"]""", re.I)


def parse_documents(html: str, audit_id: str) -> list[dict]:
    """Extract one dict per attached document from a grid page."""
    match = MYDATA_RE.search(html)
    if not match:
        if looks_like_login(html):
            raise AuthError("session expired / not logged in")
        return []

    start = html.find("[", match.end())
    if start == -1:
        return []

    try:
        # raw_decode stops cleanly at the end of the array, so the trailing
        # JavaScript on the same line doesn't confuse us.
        rows, _ = json.JSONDecoder().raw_decode(html[start:])
    except json.JSONDecodeError:
        return []

    docs = []
    for row in rows:
        href = None
        link = row.get("LinkToPDF") or ""
        found = HREF_RE.search(link)
        if found:
            href = found.group(1)
        elif row.get("ID"):
            # Fallback: rebuild the URL ourselves if the anchor markup changes.
            cap = row.get("CapId") or row.get("capId")
            if cap:
                href = f"/Audit/DisplayDocument?capId={cap}&id={row['ID']}&auditId={audit_id}"
        if not href:
            continue

        docs.append(
            {
                "audit_id": str(audit_id),
                "url": urljoin(BASE_URL, href.replace("&amp;", "&")),
                "filename": safe_filename(
                    row.get("DocumentName")
                    or f"{audit_id}_{row.get('ID', 'doc')}.pdf"
                ),
                "type": row.get("Type", ""),
                "uploaded": row.get("DateUploaded", ""),
                "original_name": row.get("OriginalFileName", ""),
            }
        )
    return docs


INVALID_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def safe_filename(name: str) -> str:
    name = INVALID_CHARS.sub("_", str(name)).strip(" .")
    return (name or "document")[:180]


# --------------------------------------------------------------------------- #
# Downloading
# --------------------------------------------------------------------------- #

print_lock = threading.Lock()
auth_failed = threading.Event()


def log(msg: str) -> None:
    with print_lock:
        print(msg, flush=True)


def fetch(session: requests.Session, url: str, *, stream: bool = False):
    """GET with retries. Raises AuthError if we get bounced to the login page."""
    last_error = None
    for attempt in range(1, RETRIES + 1):
        if auth_failed.is_set():
            raise AuthError("aborting: session expired")
        try:
            resp = session.get(url, timeout=TIMEOUT, stream=stream, allow_redirects=True)
            if resp.status_code in (401, 403):
                raise AuthError(f"HTTP {resp.status_code} on {url}")
            if "login" in resp.url.lower() and "audit" not in resp.url.lower():
                raise AuthError(f"redirected to login: {resp.url}")
            resp.raise_for_status()
            return resp
        except AuthError:
            raise
        except requests.RequestException as exc:
            last_error = exc
            if attempt < RETRIES:
                time.sleep(RETRY_BACKOFF * attempt)
    raise RuntimeError(f"failed after {RETRIES} attempts: {last_error}")


def download_document(session: requests.Session, doc: dict, out_root: Path, flat: bool) -> dict:
    """Download one PDF. Returns a result row for the report."""
    folder = out_root if flat else out_root / f"audit_{doc['audit_id']}"
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / doc["filename"]

    if target.exists() and target.stat().st_size > 0:
        return {**doc, "status": "skipped (exists)", "path": str(target), "bytes": target.stat().st_size}

    tmp = target.with_suffix(target.suffix + ".part")
    resp = fetch(session, doc["url"], stream=True)

    ctype = resp.headers.get("Content-Type", "").lower()
    if "text/html" in ctype:
        body = resp.text
        if looks_like_login(body):
            auth_failed.set()
            raise AuthError("session expired mid-run")
        return {**doc, "status": "failed (server returned HTML, not a file)", "path": "", "bytes": 0}

    size = 0
    with open(tmp, "wb") as fh:
        for chunk in resp.iter_content(chunk_size=64 * 1024):
            if chunk:
                fh.write(chunk)
                size += len(chunk)

    if size == 0:
        tmp.unlink(missing_ok=True)
        return {**doc, "status": "failed (empty response)", "path": "", "bytes": 0}

    # If the server sent a real filename, prefer its extension over the grid's.
    disp = resp.headers.get("Content-Disposition", "")
    server_name = re.search(r'filename\*?=(?:UTF-8\'\')?"?([^";]+)"?', disp, re.I)
    if server_name:
        ext = Path(safe_filename(server_name.group(1))).suffix
        if ext and ext.lower() != target.suffix.lower():
            target = target.with_suffix(ext)

    tmp.replace(target)

    with open(target, "rb") as fh:
        magic = fh.read(5)
    status = "ok" if magic.startswith(b"%PDF") else f"ok (not a PDF: {magic!r})"

    time.sleep(THROTTLE)
    return {**doc, "status": status, "path": str(target), "bytes": size}


# --------------------------------------------------------------------------- #
# Orchestration
# --------------------------------------------------------------------------- #


def load_audit_ids() -> list[str]:
    if not AUDIT_IDS_FILE.exists():
        sys.exit(f"Missing {AUDIT_IDS_FILE.name} -- put one audit id per line in it.")
    ids, seen = [], set()
    for line in AUDIT_IDS_FILE.read_text(encoding="utf-8").splitlines():
        for token in re.split(r"[,\s]+", line.strip()):
            token = token.strip()
            if token.isdigit() and token not in seen:
                seen.add(token)
                ids.append(token)
    if not ids:
        sys.exit(f"No numeric audit ids found in {AUDIT_IDS_FILE.name}.")
    return ids


def collect_documents(session: requests.Session, audit_ids: list[str], workers: int) -> list[dict]:
    """Phase 1 -- scrape every grid page and build the full document list."""
    docs: list[dict] = []
    empty: list[str] = []
    errors: list[tuple[str, str]] = []

    def work(audit_id: str):
        url = urljoin(BASE_URL, GRID_PATH.format(audit_id=audit_id, flow_id=FLOW_ID))
        resp = fetch(session, url)
        return audit_id, parse_documents(resp.text, audit_id)

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(work, aid): aid for aid in audit_ids}
        for done, future in enumerate(as_completed(futures), 1):
            audit_id = futures[future]
            try:
                _, found = future.result()
            except AuthError as exc:
                auth_failed.set()
                for f in futures:
                    f.cancel()
                sys.exit(f"\nAUTH FAILED: {exc}\nRe-copy your cookies into session.txt and rerun.")
            except Exception as exc:  # noqa: BLE001 - report and keep going
                errors.append((audit_id, str(exc)))
                log(f"  [{done}/{len(audit_ids)}] audit {audit_id}: ERROR {exc}")
                continue

            if found:
                docs.extend(found)
            else:
                empty.append(audit_id)
            log(f"  [{done}/{len(audit_ids)}] audit {audit_id}: {len(found)} document(s)")

    if empty:
        log(f"\n  {len(empty)} audit(s) had no attached documents: {', '.join(empty[:20])}"
            + (" ..." if len(empty) > 20 else ""))
    if errors:
        log(f"  {len(errors)} audit(s) errored while scanning.")
    return docs


def main() -> None:
    parser = argparse.ArgumentParser(description="Bulk-download audit PDFs using your browser session.")
    parser.add_argument("--dry-run", action="store_true", help="list documents, download nothing")
    parser.add_argument("--flat", action="store_true", help="save all PDFs in one folder")
    parser.add_argument("--workers", type=int, default=4, help="parallel downloads (default 4)")
    parser.add_argument("--out", type=Path, default=OUTPUT_DIR, help="output directory")
    args = parser.parse_args()

    session = load_session()
    audit_ids = load_audit_ids()

    print(f"Loaded {len(audit_ids)} audit id(s).")
    print("\nPhase 1/2 -- scanning grid pages for attached documents...")
    docs = collect_documents(session, audit_ids, args.workers)

    print(f"\nFound {len(docs)} document(s) across {len({d['audit_id'] for d in docs})} audit(s).")
    if not docs:
        print("Nothing to download.")
        return

    if args.dry_run:
        print("\n--dry-run: showing first 25 targets\n")
        for doc in docs[:25]:
            print(f"  audit {doc['audit_id']}  {doc['filename']}  <- {doc['url']}")
        if len(docs) > 25:
            print(f"  ... and {len(docs) - 25} more")
        return

    args.out.mkdir(parents=True, exist_ok=True)
    print(f"\nPhase 2/2 -- downloading into {args.out}\n")

    results: list[dict] = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(download_document, session, d, args.out, args.flat): d for d in docs}
        for done, future in enumerate(as_completed(futures), 1):
            doc = futures[future]
            try:
                row = future.result()
            except AuthError as exc:
                auth_failed.set()
                log(f"\nAUTH FAILED: {exc} -- stopping. Refresh session.txt and rerun "
                    "(already-downloaded files are skipped).")
                break
            except Exception as exc:  # noqa: BLE001
                row = {**doc, "status": f"failed ({exc})", "path": "", "bytes": 0}
            results.append(row)
            mark = "OK  " if row["status"].startswith("ok") else (
                "SKIP" if row["status"].startswith("skipped") else "FAIL")
            log(f"  [{done}/{len(docs)}] {mark} {row['filename']}  ({row['bytes'] / 1024:.0f} KB)")

    with open(REPORT_FILE, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(
            fh,
            fieldnames=["audit_id", "filename", "type", "uploaded", "original_name",
                        "status", "bytes", "path", "url"],
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(results)

    ok = sum(1 for r in results if r["status"].startswith("ok"))
    skipped = sum(1 for r in results if r["status"].startswith("skipped"))
    failed = len(results) - ok - skipped
    total_mb = sum(r["bytes"] for r in results) / (1024 * 1024)

    print(f"\nDone. {ok} downloaded, {skipped} already present, {failed} failed. ({total_mb:.1f} MB)")
    print(f"Report: {REPORT_FILE}")
    if failed:
        print("Re-run the script to retry only the failures -- existing files are skipped.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nInterrupted. Re-run to resume; completed files are skipped.")
