"""
Store your exlservice login in Windows Credential Manager (encrypted by Windows,
tied to your user account). Nothing is ever written to a file in this project.

    pip install keyring
    python save_credentials.py            # prompts, stores
    python save_credentials.py --show     # show stored username (never the password)
    python save_credentials.py --delete   # remove

The password is typed at a hidden prompt, so it does not land in your shell
history or in any file. chrome_session.py reads it back only if you ask it to
auto-fill the login form.
"""

from __future__ import annotations

import argparse
import getpass
import sys

SERVICE = "exlmine87.exlservice.com"
USER_KEY = "_username"  # a pseudo-entry that remembers which username to use


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--show", action="store_true")
    parser.add_argument("--delete", action="store_true")
    args = parser.parse_args()

    try:
        import keyring
    except ImportError:
        sys.exit("keyring not installed.  Run:  pip install keyring")

    if args.show:
        user = keyring.get_password(SERVICE, USER_KEY)
        if not user:
            sys.exit("No credentials stored yet. Run: python save_credentials.py")
        has_pw = keyring.get_password(SERVICE, user) is not None
        print(f"Stored username: {user}")
        print(f"Password stored: {'yes' if has_pw else 'NO'}")
        return

    if args.delete:
        user = keyring.get_password(SERVICE, USER_KEY)
        if user:
            try:
                keyring.delete_password(SERVICE, user)
            except keyring.errors.PasswordDeleteError:
                pass
            keyring.delete_password(SERVICE, USER_KEY)
            print(f"Deleted credentials for {user}.")
        else:
            print("Nothing stored.")
        return

    username = input(f"Username for {SERVICE}: ").strip()
    if not username:
        sys.exit("Cancelled.")
    password = getpass.getpass("Password (hidden): ")
    if not password:
        sys.exit("Cancelled.")

    keyring.set_password(SERVICE, username, password)
    keyring.set_password(SERVICE, USER_KEY, username)
    print(f"\nStored in Windows Credential Manager under '{SERVICE}'.")
    print("You can view/remove it any time via:  Control Panel > Credential Manager > Windows Credentials")


def load_credentials() -> tuple[str, str] | None:
    """Used by chrome_session.py. Returns (username, password) or None."""
    try:
        import keyring
    except ImportError:
        return None
    user = keyring.get_password(SERVICE, USER_KEY)
    if not user:
        return None
    password = keyring.get_password(SERVICE, user)
    return (user, password) if password else None


if __name__ == "__main__":
    main()
