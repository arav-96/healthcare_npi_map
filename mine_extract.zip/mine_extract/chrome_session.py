"""
Drive a real Chrome window, let you log in once, then hand the live session to
extract_pdfs.py.

WHY A SEPARATE CHROME PROFILE
-----------------------------
Chrome 136+ refuses --remote-debugging-port when pointed at your normal profile
directory (a security fix -- it stopped any local program from reading your main
browser session). So this opens Chrome with its own profile folder under
.chrome-profile/.

That folder persists. You log in ONCE; every later run reuses the same cookies
and goes straight through. It is a separate Chrome window from your everyday one,
and your normal Chrome keeps working untouched while this runs.

USAGE
-----
    pip install selenium
    python chrome_session.py            # opens Chrome, waits for login, saves cookies
    python extract_pdfs.py              # then download as usual

    python chrome_session.py --autofill # type stored credentials into the form for you
    python chrome_session.py --download # skip requests entirely: let Chrome do the downloads
    python chrome_session.py --headless # only works once the profile is already logged in

Selenium 4.6+ downloads the right chromedriver by itself -- nothing to install.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROFILE_DIR = HERE / ".chrome-profile"
SESSION_FILE = HERE / "session.txt"
DOWNLOAD_DIR = HERE / "downloads"

BASE_URL = "https://exlmine87.exlservice.com"
LOGIN_PROBE_URL = f"{BASE_URL}/Audit/AuditAttachedDocumentsGrid?auditIds={{audit_id}}&flowId=1"


def build_driver(headless: bool, download_dir: Path | None):
    try:
        from selenium import webdriver
    except ImportError:
        sys.exit("selenium not installed.  Run:  pip install selenium")

    options = webdriver.ChromeOptions()
    options.add_argument(f"--user-data-dir={PROFILE_DIR}")
    options.add_argument("--profile-directory=Default")
    options.add_argument("--start-maximized")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    if headless:
        options.add_argument("--headless=new")

    if download_dir:
        download_dir.mkdir(parents=True, exist_ok=True)
        options.add_experimental_option(
            "prefs",
            {
                "download.default_directory": str(download_dir),
                "download.prompt_for_download": False,
                "plugins.always_open_pdf_externally": True,  # save PDFs, don't preview them
                "profile.default_content_settings.popups": 0,
            },
        )

    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    return webdriver.Chrome(options=options)


def is_logged_in(driver, audit_id: str) -> bool:
    """Logged in == the grid page actually contains the myData payload."""
    driver.get(LOGIN_PROBE_URL.format(audit_id=audit_id))
    time.sleep(1.5)
    source = driver.page_source
    return "myData" in source and "auditAttachedDocumentsGrid" in source


def try_autofill(driver) -> bool:
    """Best-effort login-form fill from Windows Credential Manager.

    NOTE: I don't know this site's actual field ids, so this locates the password
    box and the text input nearest above it. If the form is unusual it simply
    does nothing and you log in by hand -- which always works.
    """
    from save_credentials import load_credentials

    creds = load_credentials()
    if not creds:
        print("  No stored credentials (run: python save_credentials.py). Log in manually.")
        return False

    username, password = creds
    try:
        from selenium.webdriver.common.by import By

        pw_boxes = [e for e in driver.find_elements(By.CSS_SELECTOR, "input[type='password']")
                    if e.is_displayed()]
        if not pw_boxes:
            return False
        pw = pw_boxes[0]

        text_boxes = [e for e in driver.find_elements(
            By.CSS_SELECTOR, "input[type='text'], input[type='email'], input:not([type])")
            if e.is_displayed()]
        if not text_boxes:
            return False

        text_boxes[0].clear()
        text_boxes[0].send_keys(username)
        pw.clear()
        pw.send_keys(password)
        print(f"  Filled credentials for {username}. Submit the form (handle any MFA) in the window.")
        return True
    except Exception as exc:  # noqa: BLE001
        print(f"  Autofill skipped ({exc}). Log in manually.")
        return False


def export_cookies(driver) -> int:
    """Write the live Chrome cookies to session.txt for extract_pdfs.py."""
    cookies = driver.get_cookies()
    if not cookies:
        return 0
    SESSION_FILE.write_text(
        "; ".join(f"{c['name']}={c['value']}" for c in cookies), encoding="utf-8"
    )
    return len(cookies)


def first_audit_id() -> str:
    ids_file = HERE / "audit_ids.txt"
    if ids_file.exists():
        for line in ids_file.read_text(encoding="utf-8").splitlines():
            token = line.strip()
            if token.isdigit():
                return token
    return "1119310"


def download_in_browser(driver, audit_ids: list[str]) -> None:
    """Fallback mode: navigate Chrome to each document URL and let it save the file.

    Slower and less controllable than extract_pdfs.py (no retries, no per-file
    report, files land wherever Chrome puts them) -- use it only if the
    cookie handoff is rejected by the server.
    """
    import extract_pdfs as ex

    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    total = 0
    for n, audit_id in enumerate(audit_ids, 1):
        driver.get(LOGIN_PROBE_URL.format(audit_id=audit_id))
        time.sleep(1.5)
        docs = ex.parse_documents(driver.page_source, audit_id)
        print(f"  [{n}/{len(audit_ids)}] audit {audit_id}: {len(docs)} document(s)")
        for doc in docs:
            driver.get(doc["url"])
            total += 1
            time.sleep(1.5)  # give Chrome a moment to start the transfer
    print(f"\nTriggered {total} download(s) into {DOWNLOAD_DIR}.")
    print("Wait for Chrome's download shelf to finish before closing the window.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Log in via Chrome and export the session.")
    parser.add_argument("--autofill", action="store_true",
                        help="type stored credentials into the login form")
    parser.add_argument("--headless", action="store_true",
                        help="no visible window (only if the profile is already logged in)")
    parser.add_argument("--download", action="store_true",
                        help="download through Chrome instead of exporting cookies")
    parser.add_argument("--keep-open", action="store_true",
                        help="leave Chrome open after exporting")
    args = parser.parse_args()

    probe_id = first_audit_id()
    driver = build_driver(args.headless, DOWNLOAD_DIR if args.download else None)

    try:
        print(f"Chrome profile: {PROFILE_DIR}")
        print(f"Checking session against audit {probe_id}...")

        if not is_logged_in(driver, probe_id):
            if args.headless:
                sys.exit("Not logged in, and --headless can't show you a login form.\n"
                         "Run once without --headless to log in; the profile remembers it.")
            print("\nNot logged in.")
            if args.autofill:
                try_autofill(driver)
            else:
                driver.get(BASE_URL)

            print("\n  >> Log in in the Chrome window that just opened.")
            print("  >> Waiting up to 10 minutes; this continues automatically once you're in.\n")

            deadline = time.time() + 600
            while time.time() < deadline:
                time.sleep(5)
                try:
                    if is_logged_in(driver, probe_id):
                        break
                except Exception:  # noqa: BLE001 - window busy/navigating
                    continue
            else:
                sys.exit("Timed out waiting for login.")

        print("Logged in.")

        if args.download:
            import extract_pdfs as ex
            download_in_browser(driver, ex.load_audit_ids())
            return

        count = export_cookies(driver)
        if not count:
            sys.exit("Logged in but Chrome returned no cookies -- use --download instead.")
        print(f"Exported {count} cookie(s) to {SESSION_FILE.name}.")
        print("\nNow run:  python extract_pdfs.py")

        if args.keep_open:
            input("\nPress Enter to close Chrome...")

    finally:
        if not args.keep_open:
            try:
                driver.quit()
            except Exception:  # noqa: BLE001
                pass


if __name__ == "__main__":
    main()
