# Audit PDF bulk downloader

Downloads every attached PDF for a list of audit ids, driving a real Chrome
window. You log in once, by hand, in the browser — there are no credentials,
cookies, or tokens anywhere in this project.

## Easiest: double-click, no terminal

| Double-click | What it does |
|---|---|
| `1_setup.bat` | Installs Selenium. Once, ever. |
| `3_test_first.bat` | Opens Chrome, you log in, lists what it found — downloads nothing |
| `2_run.bat` | The real download |

Put your audit ids in `audit_ids.txt` first, one per line.

## Or from a terminal

Right-click empty space inside this folder → **Open in Terminal**
(click *Show more options* if you don't see it), then:

```powershell
pip install selenium              # once
python selenium_download.py       # every run
```

That's the only dependency. Selenium 4.6+ fetches the matching chromedriver
itself, so there's nothing else to install.

## Run

1. Put your audit ids in `audit_ids.txt` — one per line.
2. ```powershell
   python selenium_download.py
   ```
3. Chrome opens. **Log in.** The script detects it and starts downloading.

Check it first on a couple of ids:

```powershell
python selenium_download.py --dry-run
```

## Options

| Flag | Effect |
|---|---|
| `--dry-run` | List what it finds, download nothing |
| `--native` | Let Chrome save files itself — use for very large PDFs |
| `--headless` | No visible window (only works after the first login) |
| `--flat` | All PDFs in one folder instead of `audit_<id>/` |
| `--out D:\pdfs` | Different output directory |

## Output

```
downloads/
  audit_1119310/
    1008700000001119310_16477914.pdf
    1008700000001119310_16477884.pdf
download_report.csv     # audit_id, filename, type, uploaded, status, bytes, path, url
```

## How it works

Each grid page embeds its document list inline as JavaScript:

```js
var myData = [{"ID":16577222,"AuditId":1119310,
               "LinkToPDF":"<a href='/Audit/DisplayDocument?capId=11413&id=16477914&auditId=1119310'>",
               "DocumentName":"1008700000001119310_16477914.pdf", ...}];
```

So the script visits each audit's grid page, parses that JSON out of the page
source, and fetches every `DisplayDocument` URL. The `capId` differs per audit,
so it's read from each row's link rather than assumed.

Downloads run through `fetch(url, {credentials:'include'})` **inside the page**,
so Chrome attaches the real session — including the `HttpOnly` `.ASPXAUTH`
cookie that JavaScript and external tools cannot read. That's why this works
where copying cookies into a `requests` script returned 401.

## Notes

- **Log in once.** The `.chrome-profile/` folder persists your session, so later
  runs go straight to downloading. `--headless` works from run 2 onward.
- **A separate Chrome profile is required.** Chrome 136+ refuses automation flags
  on your normal profile directory — a security fix that stopped local programs
  reading your main browser session. First run therefore looks like a brand-new
  browser; that's expected. Your everyday Chrome is untouched and stays usable.
- **Resumable.** Finished files are skipped, so just rerun after an interruption
  or to retry failures. Files are written to `.part` and renamed only once
  complete, so a killed run never leaves a truncated PDF.
- **Session loss is detected** — it stops with a clear message instead of quietly
  saving 400 copies of the login page.
- Audits with no attachments are reported and skipped, not treated as errors.
- **`--native` caveat:** Chrome streams to disk (good for huge files) but the
  script has to infer which file landed, so it's slower and less certain than the
  default mode. Use it only if a large PDF fails the default path.
- These are medical records — keep `downloads/` wherever your organisation's
  data-handling rules require. `downloads/` and `.chrome-profile/` are gitignored.
