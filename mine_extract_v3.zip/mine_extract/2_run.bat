@echo off
REM Double-click this to download the PDFs.
REM Chrome opens - log in - it does the rest.
REM pushd, not cd: cmd cannot cd into a \\server\share path, but pushd
REM maps it to a temporary drive letter so this works from a network folder.
pushd "%~dp0"
title Audit PDF downloader

echo ============================================
echo   Audit PDF downloader
echo ============================================
echo.
echo Chrome will open. Log in, then leave it alone.
echo Do not close the Chrome window while this runs.
echo.

REM -u = unbuffered, so progress appears live instead of all at the end
python -u selenium_download.py %*

echo.
echo ============================================
echo   Finished. The folder is printed above.
echo   Details are in download_report.csv
echo ============================================
echo.
echo Anything failed? Just run this again - completed
echo files are skipped, so it resumes where it stopped.
echo.
popd
pause
