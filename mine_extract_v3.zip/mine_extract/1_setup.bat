@echo off
REM Double-click this once to install Selenium.
REM pushd, not cd: cmd cannot cd into a \\server\share path, but pushd
REM maps it to a temporary drive letter so this works from a network folder.
pushd "%~dp0"
title Audit downloader - setup

echo ============================================
echo   Installing Selenium (one time only)
echo ============================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python was not found.
    echo.
    echo Install it from https://www.python.org/downloads/
    echo and TICK "Add python.exe to PATH" on the first screen.
    echo.
    popd
    pause
    exit /b 1
)

python -m pip install --upgrade selenium
echo.

if errorlevel 1 (
    echo Install FAILED - see the messages above.
    echo If it mentions permissions, try:  python -m pip install --user selenium
) else (
    echo Done. You can now double-click 2_run.bat
)

echo.
popd
pause
