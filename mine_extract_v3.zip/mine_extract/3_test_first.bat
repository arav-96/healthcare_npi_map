@echo off
REM Double-click this to check login + parsing WITHOUT downloading anything.
REM Run this before 2_run.bat the first time.
REM pushd, not cd: cmd cannot cd into a \\server\share path, but pushd
REM maps it to a temporary drive letter so this works from a network folder.
pushd "%~dp0"
title Audit PDF downloader - dry run

echo ============================================
echo   DRY RUN - nothing will be downloaded
echo ============================================
echo.
echo Chrome will open. Log in, then leave it alone.
echo.

python -u selenium_download.py --dry-run

echo.
echo ============================================
echo   If the list above looks right, you are set:
echo   double-click 2_run.bat to download for real.
echo ============================================
echo.
popd
pause
