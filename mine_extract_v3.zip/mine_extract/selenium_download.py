"""
Bulk-download audit PDFs entirely inside a real Chrome window (Selenium).

No cookie copying, no session.txt, no 401s: every request is issued by the
browser itself, from the same tab you logged in with. If the site pins the
session to the browser (IP, TLS fingerprint, User-Agent), this still works
where cookie replay cannot.

    pip install selenium
    python selenium_download.py

    python selenium_download.py --dry-run    # list what it finds, download nothing
    python selenium_download.py --native     # use Chrome's own downloader (see below)
    python selenium_download.py --headless   # no window (only after first login)
    python selenium_download.py --flat       # one folder instead of audit_<id>/

FIRST RUN
---------
A Chrome window opens with its own profile (.chrome-profile/). Log in. The
script waits, detects it, and starts. That profile persists, so later runs go
straight through without asking.

    Why a separate profile? Chrome 136+ refuses automation flags on your normal
    profile directory -- a security fix that stopped local programs reading your
    main browser session. Your everyday Chrome is untouched and stays usable.

TWO DOWNLOAD MODES
------------------
default   fetch() inside the page, bytes handed back to Python. Exact filenames,
          verified sizes, resumable. Best for typical files.
--native  Chrome saves the file itself. Slower and it has to guess which file
          landed, but it streams to disk, so use it for very large PDFs
          (fetch mode holds each file in browser memory).
"""

from __future__ import annotations

import argparse
import base64
import csv
import json
import os
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path
from urllib.parse import urljoin

HERE = Path(__file__).resolve().parent
AUDIT_IDS_FILE = HERE / "audit_ids.txt"
DOWNLOAD_PATH_FILE = HERE / "download_path.txt"   # edit this to change where PDFs go
OUTPUT_DIR = HERE / "downloads"                   # used when that file says nothing
REPORT_FILE = HERE / "download_report.csv"


def is_network_path(path: Path) -> bool:
    """True for UNC paths (\\\\server\\share\\...)."""
    return str(path).startswith("\\\\") or str(path).startswith("//")


def local_app_dir(*parts: str) -> Path:
    """A directory on the local disk, whatever drive the script itself is on."""
    base = os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()
    return Path(base) / "audit_pdf_downloader" / Path(*parts)


# Chrome REFUSES to start when --user-data-dir points at a network share, so the
# profile always lives on local disk -- even when this script runs from a UNC
# path or a mapped network drive. It still persists between runs.
PROFILE_DIR = local_app_dir("chrome-profile")

BASE_URL = "https://exlmine87.exlservice.com"
GRID_URL = BASE_URL + "/Audit/AuditAttachedDocumentsGrid?auditIds={audit_id}&flowId=1"

PAGE_SETTLE = 1.2      # seconds to let the grid's 500ms JS timer render
FETCH_TIMEOUT = 300    # per-file, seconds
RETRIES = 3
LOGIN_WAIT = 600       # seconds to wait for you to log in

# --------------------------------------------------------------------------- #
# Parsing (same logic as extract_pdfs.py, inlined so this file stands alone)
# --------------------------------------------------------------------------- #

MYDATA_RE = re.compile(r"var\s+myData\s*=\s*", re.I)
HREF_RE = re.compile(r"""href\s*=\s*['"]([^'"]+DisplayDocument[^'"]*)['"]""", re.I)
INVALID_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def safe_filename(name: str) -> str:
    name = INVALID_CHARS.sub("_", str(name)).strip(" .")
    return (name or "document")[:180]


def parse_documents(html: str, audit_id: str) -> list[dict]:
    """Pull one dict per attached document out of a grid page."""
    match = MYDATA_RE.search(html)
    if not match:
        return []
    start = html.find("[", match.end())
    if start == -1:
        return []
    try:
        rows, _ = json.JSONDecoder().raw_decode(html[start:])
    except json.JSONDecodeError:
        return []

    docs = []
    for row in rows:
        found = HREF_RE.search(row.get("LinkToPDF") or "")
        if not found:
            continue
        docs.append({
            "audit_id": str(audit_id),
            "url": urljoin(BASE_URL, found.group(1).replace("&amp;", "&")),
            "filename": safe_filename(row.get("DocumentName") or f"{audit_id}_{row.get('ID')}.pdf"),
            "type": row.get("Type", ""),
            "uploaded": row.get("DateUploaded", ""),
            "original_name": row.get("OriginalFileName", ""),
        })
    return docs


def load_output_dir() -> tuple[Path, str]:
    """Read the destination folder from download_path.txt.

    Returns (folder, where_it_came_from). Falls back to ./downloads when the
    file is missing or fully commented out.
    """
    if not DOWNLOAD_PATH_FILE.exists():
        return OUTPUT_DIR, "default (download_path.txt not found)"

    for line in DOWNLOAD_PATH_FILE.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        line = line.strip('"').strip("'").strip()
        if not line:
            continue
        expanded = os.path.expandvars(os.path.expanduser(line))
        if "%" in expanded:
            sys.exit(f"download_path.txt: unknown variable in path:\n  {line}")
        return Path(expanded), f"download_path.txt"

    return OUTPUT_DIR, "default (download_path.txt has no active line)"


def load_audit_ids() -> list[str]:
    if not AUDIT_IDS_FILE.exists():
        sys.exit(f"Missing {AUDIT_IDS_FILE.name} -- put one audit id per line in it.")
    ids, seen = [], set()
    for line in AUDIT_IDS_FILE.read_text(encoding="utf-8").splitlines():
        if line.strip().startswith("#"):
            continue
        for token in re.split(r"[,\s]+", line.strip()):
            if token.isdigit() and token not in seen:
                seen.add(token)
                ids.append(token)
    if not ids:
        sys.exit(f"No numeric audit ids found in {AUDIT_IDS_FILE.name}.")
    return ids


# --------------------------------------------------------------------------- #
# Browser
# --------------------------------------------------------------------------- #

# Runs in the page, so the browser attaches its own cookies/TLS/headers.
# Returns the file as a data: URL, or an error object.
FETCH_JS = r"""
const url = arguments[0];
const done = arguments[arguments.length - 1];
fetch(url, { credentials: 'include' })
  .then(r => {
    if (!r.ok) { done({ ok: false, status: r.status }); return null; }
    const ct = r.headers.get('Content-Type') || '';
    const cd = r.headers.get('Content-Disposition') || '';
    return r.blob().then(b => ({ blob: b, ct: ct, cd: cd, status: r.status }));
  })
  .then(res => {
    if (!res) return;
    const reader = new FileReader();
    reader.onloadend = () => done({ ok: true, status: res.status, ct: res.ct,
                                    cd: res.cd, data: reader.result });
    reader.onerror = () => done({ ok: false, error: 'FileReader failed' });
    reader.readAsDataURL(res.blob);
  })
  .catch(e => done({ ok: false, error: String(e) }));
"""


CHROME_GUESSES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
]


def find_chrome() -> str | None:
    for guess in CHROME_GUESSES:
        if guess and Path(guess).exists():
            return guess
    return None


def make_options(profile_dir: Path, headless: bool, staging: Path | None,
                 chrome_binary: str | None, hardened: bool):
    from selenium import webdriver

    options = webdriver.ChromeOptions()
    profile_dir.mkdir(parents=True, exist_ok=True)
    options.add_argument(f"--user-data-dir={profile_dir}")
    options.add_argument("--profile-directory=Default")
    options.add_argument("--start-maximized")
    options.add_argument("--no-first-run")
    options.add_argument("--no-default-browser-check")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])

    if headless:
        options.add_argument("--headless=new")
    if chrome_binary:
        options.binary_location = chrome_binary
    if hardened:
        # Fallbacks for locked-down corporate machines.
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")

    if staging:
        options.add_experimental_option("prefs", {
            "download.default_directory": str(staging),
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "plugins.always_open_pdf_externally": True,   # save, don't preview
            "profile.default_content_settings.popups": 0,
        })
    return options


def build_driver(headless: bool, staging: Path | None, profile_dir: Path,
                 chrome_binary: str | None):
    """Start Chrome, retrying with progressively safer settings.

    The usual failure is 'Chrome instance exited' because --user-data-dir pointed
    at a network share. PROFILE_DIR is local by default, but the retries cover
    a locked profile, a stale lock file, or a hardened corporate build.
    """
    try:
        from selenium import webdriver
        from selenium.common.exceptions import WebDriverException
    except ImportError:
        sys.exit("selenium not installed.  Run:  pip install selenium")

    if chrome_binary is None:
        chrome_binary = find_chrome()

    attempts = [
        ("profile on local disk", profile_dir, False),
        ("fresh temporary profile", Path(tempfile.mkdtemp(prefix="chrome-prof-")), False),
        ("temporary profile + relaxed sandbox", Path(tempfile.mkdtemp(prefix="chrome-prof-")), True),
    ]

    last_error: Exception | None = None
    for label, prof, hardened in attempts:
        try:
            options = make_options(prof, headless, staging, chrome_binary, hardened)
            driver = webdriver.Chrome(options=options)
            driver.set_script_timeout(FETCH_TIMEOUT)
            if prof != profile_dir:
                print(f"  NOTE: started with a {label} -- you will have to log in again this run.")
            return driver
        except WebDriverException as exc:
            last_error = exc
            first_line = str(exc).splitlines()[0]
            print(f"  Chrome failed to start ({label}): {first_line}")

    explain_startup_failure(chrome_binary, profile_dir)
    raise SystemExit(1) from last_error


def explain_startup_failure(chrome_binary: str | None, profile_dir: Path) -> None:
    print("\n" + "=" * 68)
    print("  Chrome would not start. Most likely causes, in order:")
    print("=" * 68)
    if not chrome_binary:
        print("  1. Chrome is not installed in a standard location.")
        print("     Find chrome.exe and pass it:")
        print("        python selenium_download.py --chrome-binary \"C:\\path\\to\\chrome.exe\"")
    else:
        print(f"  1. Chrome found at: {chrome_binary}")
    print(f"  2. Profile directory: {profile_dir}")
    if is_network_path(profile_dir):
        print("     ^^ THIS IS A NETWORK PATH. Chrome refuses to run from one.")
        print("        Pass a local one:  --profile C:\\Users\\<you>\\chrome-profile")
    print("  3. Another Chrome is already using that profile -- close all windows")
    print("     of the automation Chrome, then retry.")
    print("  4. Corporate policy blocks automation. Try:  --chrome-binary <path>")
    print("     or ask IT whether ChromeDriver is permitted.")
    print("  5. Selenium could not download a matching chromedriver (no internet")
    print("     access to the driver CDN). Check with your network team.")
    print("=" * 68)


def open_grid(driver, audit_id: str) -> str:
    driver.get(GRID_URL.format(audit_id=audit_id))
    time.sleep(PAGE_SETTLE)  # the page renders myData on a 500ms setTimeout
    return driver.page_source


def wait_for_login(driver, probe_id: str, headless: bool) -> None:
    html = open_grid(driver, probe_id)
    if "myData" in html:
        print("Already logged in (profile remembered it).")
        return

    if headless:
        sys.exit("Not logged in, and --headless can't show a login form.\n"
                 "Run once without --headless first.")

    driver.get(BASE_URL)
    print("\n  >> Log in in the Chrome window that just opened.")
    print(f"  >> Waiting up to {LOGIN_WAIT // 60} minutes; this continues by itself.\n")

    deadline = time.time() + LOGIN_WAIT
    while time.time() < deadline:
        time.sleep(5)
        try:
            if "myData" in open_grid(driver, probe_id):
                print("Logged in.\n")
                return
        except Exception:  # noqa: BLE001 - window mid-navigation
            continue
    sys.exit("Timed out waiting for login.")


# --------------------------------------------------------------------------- #
# Downloading
# --------------------------------------------------------------------------- #


def fetch_in_page(driver, doc: dict, target: Path) -> dict:
    """Download via fetch() inside the page and write the bytes from Python."""
    last = "unknown error"
    for attempt in range(1, RETRIES + 1):
        try:
            result = driver.execute_async_script(FETCH_JS, doc["url"])
        except Exception as exc:  # noqa: BLE001 - script timeout, tab crash...
            last = f"{type(exc).__name__}: {str(exc).splitlines()[0]}"
            time.sleep(2 * attempt)
            continue

        if not result or not result.get("ok"):
            status = (result or {}).get("status")
            last = f"HTTP {status}" if status else (result or {}).get("error", "no response")
            if status in (401, 403):
                return {**doc, "status": f"auth failed ({last})", "path": "", "bytes": 0}
            time.sleep(2 * attempt)
            continue

        data_url = result.get("data") or ""
        if "," not in data_url:
            last = "empty payload"
            continue

        header, _, b64 = data_url.partition(",")
        blob = base64.b64decode(b64)
        if not blob:
            last = "zero bytes"
            continue

        if b"<html" in blob[:600].lower() and not blob.startswith(b"%PDF"):
            return {**doc, "status": "failed (got HTML, not a file)", "path": "", "bytes": 0}

        # Trust the server's extension if it disagrees with the grid's.
        server_name = re.search(r'filename\*?=(?:UTF-8\'\')?"?([^";]+)"?',
                                result.get("cd", ""), re.I)
        if server_name:
            ext = Path(safe_filename(server_name.group(1))).suffix
            if ext and ext.lower() != target.suffix.lower():
                target = target.with_suffix(ext)

        tmp = target.with_suffix(target.suffix + ".part")
        tmp.write_bytes(blob)
        tmp.replace(target)

        ok = blob.startswith(b"%PDF")
        return {**doc, "status": "ok" if ok else f"ok (not a PDF: {blob[:5]!r})",
                "path": str(target), "bytes": len(blob)}

    return {**doc, "status": f"failed ({last})", "path": "", "bytes": 0}


def fetch_native(driver, doc: dict, target: Path, staging: Path) -> dict:
    """Let Chrome download the file, then move it into place."""
    before = set(staging.iterdir()) if staging.exists() else set()
    driver.get(doc["url"])

    deadline = time.time() + FETCH_TIMEOUT
    landed = None
    while time.time() < deadline:
        time.sleep(0.7)
        current = set(staging.iterdir())
        fresh = [p for p in current - before if not p.name.endswith(".crdownload")]
        if fresh and not any(p.name.endswith(".crdownload") for p in current):
            landed = max(fresh, key=lambda p: p.stat().st_mtime)
            break

    if not landed:
        return {**doc, "status": "failed (no file appeared)", "path": "", "bytes": 0}

    size = landed.stat().st_size
    if landed.suffix.lower() != target.suffix.lower():
        target = target.with_suffix(landed.suffix)
    # shutil.move, not Path.replace: staging is local disk while the output dir
    # may be a network share, and os.replace cannot cross volumes.
    shutil.move(str(landed), str(target))

    with open(target, "rb") as fh:
        ok = fh.read(5).startswith(b"%PDF")
    return {**doc, "status": "ok" if ok else "ok (not a PDF)", "path": str(target), "bytes": size}


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #


def main() -> None:
    parser = argparse.ArgumentParser(description="Download audit PDFs through a real Chrome session.")
    parser.add_argument("--dry-run", action="store_true", help="list documents, download nothing")
    parser.add_argument("--native", action="store_true", help="use Chrome's own downloader")
    parser.add_argument("--headless", action="store_true", help="no window (after first login)")
    parser.add_argument("--flat", action="store_true", help="one folder instead of audit_<id>/")
    parser.add_argument("--out", type=Path, default=None,
                        help="output folder; overrides download_path.txt for this run")
    parser.add_argument("--profile", type=Path, default=PROFILE_DIR,
                        help="Chrome profile dir (must be on LOCAL disk, not a network share)")
    parser.add_argument("--chrome-binary", default=None,
                        help=r'path to chrome.exe if it is not in a standard location')
    args = parser.parse_args()

    audit_ids = load_audit_ids()

    if args.out is not None:
        out_dir, out_source = args.out, "--out on the command line"
    else:
        out_dir, out_source = load_output_dir()
    args.out = out_dir

    try:
        out_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        sys.exit(f"Cannot create the download folder:\n  {out_dir}\n  {exc}\n"
                 f"(from {out_source}) -- fix the path in download_path.txt")

    if is_network_path(args.profile):
        sys.exit(f"Profile dir is on a network share:\n  {args.profile}\n"
                 "Chrome cannot start from one. Drop --profile to use the local default.")

    # Chrome's own downloader can't reliably write to a UNC share either, so it
    # stages locally and Python moves each finished file to the real output dir.
    staging = local_app_dir("incoming") if args.native else None
    if staging:
        staging.mkdir(parents=True, exist_ok=True)

    print(f"{len(audit_ids)} audit id(s) | mode: {'Chrome downloader' if args.native else 'in-page fetch'}")
    print(f"Saving to     : {out_dir}   [{out_source}]")
    print(f"Chrome profile: {args.profile}")
    if is_network_path(HERE):
        print("Script is on a network share -- Chrome profile kept on local disk (required).")
    print()

    driver = build_driver(args.headless, staging, args.profile, args.chrome_binary)
    results: list[dict] = []

    try:
        wait_for_login(driver, audit_ids[0], args.headless)

        for n, audit_id in enumerate(audit_ids, 1):
            try:
                html = open_grid(driver, audit_id)
            except Exception as exc:  # noqa: BLE001
                print(f"[{n}/{len(audit_ids)}] audit {audit_id}: page error {exc}")
                continue

            if "myData" not in html:
                print(f"[{n}/{len(audit_ids)}] audit {audit_id}: SESSION LOST -- log in again and rerun")
                break

            docs = parse_documents(html, audit_id)
            print(f"[{n}/{len(audit_ids)}] audit {audit_id}: {len(docs)} document(s)")

            folder = args.out if args.flat else args.out / f"audit_{audit_id}"
            for doc in docs:
                if args.dry_run:
                    print(f"      would get {doc['filename']}")
                    results.append({**doc, "status": "dry-run", "path": "", "bytes": 0})
                    continue

                folder.mkdir(parents=True, exist_ok=True)
                target = folder / doc["filename"]
                if target.exists() and target.stat().st_size > 0:
                    print(f"      SKIP {doc['filename']} (already downloaded)")
                    results.append({**doc, "status": "skipped (exists)",
                                    "path": str(target), "bytes": target.stat().st_size})
                    continue

                row = (fetch_native(driver, doc, target, staging) if args.native
                       else fetch_in_page(driver, doc, target))
                results.append(row)
                mark = "OK  " if row["status"].startswith("ok") else "FAIL"
                print(f"      {mark} {doc['filename']}  ({row['bytes'] / 1024:.0f} KB)")

                if row["status"].startswith("auth failed"):
                    print("\n  Session rejected mid-run. Log in again and rerun "
                          "(finished files are skipped).")
                    raise SystemExit(1)

    except KeyboardInterrupt:
        print("\nInterrupted -- rerun to resume; finished files are skipped.")
    except SystemExit:
        pass
    finally:
        report = out_dir / REPORT_FILE.name   # keep the report beside the PDFs
        if results:
            with open(report, "w", newline="", encoding="utf-8") as fh:
                writer = csv.DictWriter(
                    fh,
                    fieldnames=["audit_id", "filename", "type", "uploaded",
                                "original_name", "status", "bytes", "path", "url"],
                    extrasaction="ignore")
                writer.writeheader()
                writer.writerows(results)

        try:
            if staging and staging.exists() and not any(staging.iterdir()):
                staging.rmdir()
        except OSError:
            pass
        try:
            driver.quit()
        except Exception:  # noqa: BLE001
            pass

    ok = sum(1 for r in results if r["status"].startswith("ok"))
    skipped = sum(1 for r in results if r["status"].startswith("skipped"))
    failed = len(results) - ok - skipped - sum(1 for r in results if r["status"] == "dry-run")
    total_mb = sum(r["bytes"] for r in results) / (1024 * 1024)

    print(f"\nDone. {ok} downloaded, {skipped} already present, {failed} failed. ({total_mb:.1f} MB)")
    print(f"Saved to: {out_dir}")
    if results:
        print(f"Report  : {out_dir / REPORT_FILE.name}")


if __name__ == "__main__":
    main()
