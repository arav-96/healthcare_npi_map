"""
Bulk-download audit PDFs entirely inside a real Chrome window (Selenium).

No cookie copying, no session.txt, no 401s: every request is issued by the
browser itself, from the same tab you logged in with. If the site pins the
session to the browser (IP, TLS fingerprint, User-Agent), this still works
where cookie replay cannot.

    pip install selenium
    python selenium_download.py

    python selenium_download.py --dry-run    # list what it finds, download nothing
    python selenium_download.py --native     # use Chrome's own downloader (see below)
    python selenium_download.py --headless   # no window (only after first login)
    python selenium_download.py --flat       # one folder instead of audit_<id>/

FIRST RUN
---------
A Chrome window opens with its own profile (.chrome-profile/). Log in. The
script waits, detects it, and starts. That profile persists, so later runs go
straight through without asking.

    Why a separate profile? Chrome 136+ refuses automation flags on your normal
    profile directory -- a security fix that stopped local programs reading your
    main browser session. Your everyday Chrome is untouched and stays usable.

TWO DOWNLOAD MODES
------------------
default   fetch() inside the page, bytes handed back to Python. Exact filenames,
          verified sizes, resumable. Best for typical files.
--native  Chrome saves the file itself. Slower and it has to guess which file
          landed, but it streams to disk, so use it for very large PDFs
          (fetch mode holds each file in browser memory).
"""

from __future__ import annotations

import argparse
import base64
import csv
import json
import re
import sys
import time
from pathlib import Path
from urllib.parse import urljoin

HERE = Path(__file__).resolve().parent
PROFILE_DIR = HERE / ".chrome-profile"
AUDIT_IDS_FILE = HERE / "audit_ids.txt"
OUTPUT_DIR = HERE / "downloads"
REPORT_FILE = HERE / "download_report.csv"

BASE_URL = "https://exlmine87.exlservice.com"
GRID_URL = BASE_URL + "/Audit/AuditAttachedDocumentsGrid?auditIds={audit_id}&flowId=1"

PAGE_SETTLE = 1.2      # seconds to let the grid's 500ms JS timer render
FETCH_TIMEOUT = 300    # per-file, seconds
RETRIES = 3
LOGIN_WAIT = 600       # seconds to wait for you to log in

# --------------------------------------------------------------------------- #
# Parsing (same logic as extract_pdfs.py, inlined so this file stands alone)
# --------------------------------------------------------------------------- #

MYDATA_RE = re.compile(r"var\s+myData\s*=\s*", re.I)
HREF_RE = re.compile(r"""href\s*=\s*['"]([^'"]+DisplayDocument[^'"]*)['"]""", re.I)
INVALID_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def safe_filename(name: str) -> str:
    name = INVALID_CHARS.sub("_", str(name)).strip(" .")
    return (name or "document")[:180]


def parse_documents(html: str, audit_id: str) -> list[dict]:
    """Pull one dict per attached document out of a grid page."""
    match = MYDATA_RE.search(html)
    if not match:
        return []
    start = html.find("[", match.end())
    if start == -1:
        return []
    try:
        rows, _ = json.JSONDecoder().raw_decode(html[start:])
    except json.JSONDecodeError:
        return []

    docs = []
    for row in rows:
        found = HREF_RE.search(row.get("LinkToPDF") or "")
        if not found:
            continue
        docs.append({
            "audit_id": str(audit_id),
            "url": urljoin(BASE_URL, found.group(1).replace("&amp;", "&")),
            "filename": safe_filename(row.get("DocumentName") or f"{audit_id}_{row.get('ID')}.pdf"),
            "type": row.get("Type", ""),
            "uploaded": row.get("DateUploaded", ""),
            "original_name": row.get("OriginalFileName", ""),
        })
    return docs


def load_audit_ids() -> list[str]:
    if not AUDIT_IDS_FILE.exists():
        sys.exit(f"Missing {AUDIT_IDS_FILE.name} -- put one audit id per line in it.")
    ids, seen = [], set()
    for line in AUDIT_IDS_FILE.read_text(encoding="utf-8").splitlines():
        if line.strip().startswith("#"):
            continue
        for token in re.split(r"[,\s]+", line.strip()):
            if token.isdigit() and token not in seen:
                seen.add(token)
                ids.append(token)
    if not ids:
        sys.exit(f"No numeric audit ids found in {AUDIT_IDS_FILE.name}.")
    return ids


# --------------------------------------------------------------------------- #
# Browser
# --------------------------------------------------------------------------- #

# Runs in the page, so the browser attaches its own cookies/TLS/headers.
# Returns the file as a data: URL, or an error object.
FETCH_JS = r"""
const url = arguments[0];
const done = arguments[arguments.length - 1];
fetch(url, { credentials: 'include' })
  .then(r => {
    if (!r.ok) { done({ ok: false, status: r.status }); return null; }
    const ct = r.headers.get('Content-Type') || '';
    const cd = r.headers.get('Content-Disposition') || '';
    return r.blob().then(b => ({ blob: b, ct: ct, cd: cd, status: r.status }));
  })
  .then(res => {
    if (!res) return;
    const reader = new FileReader();
    reader.onloadend = () => done({ ok: true, status: res.status, ct: res.ct,
                                    cd: res.cd, data: reader.result });
    reader.onerror = () => done({ ok: false, error: 'FileReader failed' });
    reader.readAsDataURL(res.blob);
  })
  .catch(e => done({ ok: false, error: String(e) }));
"""


def build_driver(headless: bool, native: bool, out_dir: Path):
    try:
        from selenium import webdriver
    except ImportError:
        sys.exit("selenium not installed.  Run:  pip install selenium")

    options = webdriver.ChromeOptions()
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    options.add_argument(f"--user-data-dir={PROFILE_DIR}")
    options.add_argument("--profile-directory=Default")
    options.add_argument("--start-maximized")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    if headless:
        options.add_argument("--headless=new")

    if native:
        staging = out_dir / "_incoming"
        staging.mkdir(parents=True, exist_ok=True)
        options.add_experimental_option("prefs", {
            "download.default_directory": str(staging),
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "plugins.always_open_pdf_externally": True,   # save, don't preview
            "profile.default_content_settings.popups": 0,
        })

    driver = webdriver.Chrome(options=options)
    driver.set_script_timeout(FETCH_TIMEOUT)
    return driver


def open_grid(driver, audit_id: str) -> str:
    driver.get(GRID_URL.format(audit_id=audit_id))
    time.sleep(PAGE_SETTLE)  # the page renders myData on a 500ms setTimeout
    return driver.page_source


def wait_for_login(driver, probe_id: str, headless: bool) -> None:
    html = open_grid(driver, probe_id)
    if "myData" in html:
        print("Already logged in (profile remembered it).")
        return

    if headless:
        sys.exit("Not logged in, and --headless can't show a login form.\n"
                 "Run once without --headless first.")

    driver.get(BASE_URL)
    print("\n  >> Log in in the Chrome window that just opened.")
    print(f"  >> Waiting up to {LOGIN_WAIT // 60} minutes; this continues by itself.\n")

    deadline = time.time() + LOGIN_WAIT
    while time.time() < deadline:
        time.sleep(5)
        try:
            if "myData" in open_grid(driver, probe_id):
                print("Logged in.\n")
                return
        except Exception:  # noqa: BLE001 - window mid-navigation
            continue
    sys.exit("Timed out waiting for login.")


# --------------------------------------------------------------------------- #
# Downloading
# --------------------------------------------------------------------------- #


def fetch_in_page(driver, doc: dict, target: Path) -> dict:
    """Download via fetch() inside the page and write the bytes from Python."""
    last = "unknown error"
    for attempt in range(1, RETRIES + 1):
        try:
            result = driver.execute_async_script(FETCH_JS, doc["url"])
        except Exception as exc:  # noqa: BLE001 - script timeout, tab crash...
            last = f"{type(exc).__name__}: {str(exc).splitlines()[0]}"
            time.sleep(2 * attempt)
            continue

        if not result or not result.get("ok"):
            status = (result or {}).get("status")
            last = f"HTTP {status}" if status else (result or {}).get("error", "no response")
            if status in (401, 403):
                return {**doc, "status": f"auth failed ({last})", "path": "", "bytes": 0}
            time.sleep(2 * attempt)
            continue

        data_url = result.get("data") or ""
        if "," not in data_url:
            last = "empty payload"
            continue

        header, _, b64 = data_url.partition(",")
        blob = base64.b64decode(b64)
        if not blob:
            last = "zero bytes"
            continue

        if b"<html" in blob[:600].lower() and not blob.startswith(b"%PDF"):
            return {**doc, "status": "failed (got HTML, not a file)", "path": "", "bytes": 0}

        # Trust the server's extension if it disagrees with the grid's.
        server_name = re.search(r'filename\*?=(?:UTF-8\'\')?"?([^";]+)"?',
                                result.get("cd", ""), re.I)
        if server_name:
            ext = Path(safe_filename(server_name.group(1))).suffix
            if ext and ext.lower() != target.suffix.lower():
                target = target.with_suffix(ext)

        tmp = target.with_suffix(target.suffix + ".part")
        tmp.write_bytes(blob)
        tmp.replace(target)

        ok = blob.startswith(b"%PDF")
        return {**doc, "status": "ok" if ok else f"ok (not a PDF: {blob[:5]!r})",
                "path": str(target), "bytes": len(blob)}

    return {**doc, "status": f"failed ({last})", "path": "", "bytes": 0}


def fetch_native(driver, doc: dict, target: Path, staging: Path) -> dict:
    """Let Chrome download the file, then move it into place."""
    before = set(staging.iterdir()) if staging.exists() else set()
    driver.get(doc["url"])

    deadline = time.time() + FETCH_TIMEOUT
    landed = None
    while time.time() < deadline:
        time.sleep(0.7)
        current = set(staging.iterdir())
        fresh = [p for p in current - before if not p.name.endswith(".crdownload")]
        if fresh and not any(p.name.endswith(".crdownload") for p in current):
            landed = max(fresh, key=lambda p: p.stat().st_mtime)
            break

    if not landed:
        return {**doc, "status": "failed (no file appeared)", "path": "", "bytes": 0}

    size = landed.stat().st_size
    if landed.suffix.lower() != target.suffix.lower():
        target = target.with_suffix(landed.suffix)
    landed.replace(target)

    with open(target, "rb") as fh:
        ok = fh.read(5).startswith(b"%PDF")
    return {**doc, "status": "ok" if ok else "ok (not a PDF)", "path": str(target), "bytes": size}


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #


def main() -> None:
    parser = argparse.ArgumentParser(description="Download audit PDFs through a real Chrome session.")
    parser.add_argument("--dry-run", action="store_true", help="list documents, download nothing")
    parser.add_argument("--native", action="store_true", help="use Chrome's own downloader")
    parser.add_argument("--headless", action="store_true", help="no window (after first login)")
    parser.add_argument("--flat", action="store_true", help="one folder instead of audit_<id>/")
    parser.add_argument("--out", type=Path, default=OUTPUT_DIR)
    args = parser.parse_args()

    audit_ids = load_audit_ids()
    args.out.mkdir(parents=True, exist_ok=True)
    staging = args.out / "_incoming"

    print(f"{len(audit_ids)} audit id(s) | mode: {'Chrome downloader' if args.native else 'in-page fetch'}")
    print(f"Chrome profile: {PROFILE_DIR}\n")

    driver = build_driver(args.headless, args.native, args.out)
    results: list[dict] = []

    try:
        wait_for_login(driver, audit_ids[0], args.headless)

        for n, audit_id in enumerate(audit_ids, 1):
            try:
                html = open_grid(driver, audit_id)
            except Exception as exc:  # noqa: BLE001
                print(f"[{n}/{len(audit_ids)}] audit {audit_id}: page error {exc}")
                continue

            if "myData" not in html:
                print(f"[{n}/{len(audit_ids)}] audit {audit_id}: SESSION LOST -- log in again and rerun")
                break

            docs = parse_documents(html, audit_id)
            print(f"[{n}/{len(audit_ids)}] audit {audit_id}: {len(docs)} document(s)")

            folder = args.out if args.flat else args.out / f"audit_{audit_id}"
            for doc in docs:
                if args.dry_run:
                    print(f"      would get {doc['filename']}")
                    results.append({**doc, "status": "dry-run", "path": "", "bytes": 0})
                    continue

                folder.mkdir(parents=True, exist_ok=True)
                target = folder / doc["filename"]
                if target.exists() and target.stat().st_size > 0:
                    print(f"      SKIP {doc['filename']} (already downloaded)")
                    results.append({**doc, "status": "skipped (exists)",
                                    "path": str(target), "bytes": target.stat().st_size})
                    continue

                row = (fetch_native(driver, doc, target, staging) if args.native
                       else fetch_in_page(driver, doc, target))
                results.append(row)
                mark = "OK  " if row["status"].startswith("ok") else "FAIL"
                print(f"      {mark} {doc['filename']}  ({row['bytes'] / 1024:.0f} KB)")

                if row["status"].startswith("auth failed"):
                    print("\n  Session rejected mid-run. Log in again and rerun "
                          "(finished files are skipped).")
                    raise SystemExit(1)

    except KeyboardInterrupt:
        print("\nInterrupted -- rerun to resume; finished files are skipped.")
    except SystemExit:
        pass
    finally:
        if results:
            with open(REPORT_FILE, "w", newline="", encoding="utf-8") as fh:
                writer = csv.DictWriter(
                    fh,
                    fieldnames=["audit_id", "filename", "type", "uploaded",
                                "original_name", "status", "bytes", "path", "url"],
                    extrasaction="ignore")
                writer.writeheader()
                writer.writerows(results)

        try:
            if staging.exists() and not any(staging.iterdir()):
                staging.rmdir()
        except OSError:
            pass
        try:
            driver.quit()
        except Exception:  # noqa: BLE001
            pass

    ok = sum(1 for r in results if r["status"].startswith("ok"))
    skipped = sum(1 for r in results if r["status"].startswith("skipped"))
    failed = len(results) - ok - skipped - sum(1 for r in results if r["status"] == "dry-run")
    total_mb = sum(r["bytes"] for r in results) / (1024 * 1024)

    print(f"\nDone. {ok} downloaded, {skipped} already present, {failed} failed. ({total_mb:.1f} MB)")
    if results:
        print(f"Report: {REPORT_FILE}")


if __name__ == "__main__":
    main()
